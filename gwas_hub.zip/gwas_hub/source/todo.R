# Limit search to study and analysis #
# Limit search to keyword (keyword search) #
# Mask p value #
# Use icons for submit buttons #
# Add URL in result table; Create URL builder functions #
# Add percentile in result table #
# Add "Clear All" button (Use updateInput functions?) #
# Create dbSNP database and update GWAS database
# Genome versions
# Make plots #
# Build a keyword dictionary; make a keyword table, develop a keywor enrichment analysis #
# introduction using markdown
# URL link in enrichment table
# Search limit to 'keyword'